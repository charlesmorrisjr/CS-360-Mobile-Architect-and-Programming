package com.example.weighttracker

import RecyclerViewItemDecoration
import android.content.ContentValues
import android.os.Bundle
import android.provider.BaseColumns
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.weighttracker.MainActivity.FeedReaderContract.DailyWeights
import com.example.weighttracker.MainActivity.FeedReaderContract.FeedReaderDbHelper
import com.example.weighttracker.MainActivity.MyData
import com.example.weighttracker.databinding.FragmentSecondBinding
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.random.Random

/**
 * A simple [Fragment] subclass as the second destination in the navigation.
 */
class SecondFragment : Fragment() {
    private var _binding: FragmentSecondBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    // Data for the recycler view
    private var recyclerData = mutableListOf<MyData>()

    private val sharedViewModel: SharedViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        // Show the app bar on this fragment
        (activity as AppCompatActivity).supportActionBar?.show()

        // Hide the app bar's back button
        (activity as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(false)

        _binding = FragmentSecondBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Get the daily weights from the database
        recyclerData = getDailyWeights()
        sharedViewModel.recyclerData = recyclerData

        // If the recycler view is empty, show a dialog to ask the user if they want to generate some data
        // (For testing purposes only -- this will be removed in the final version)
        if (recyclerData.isEmpty()) {
            val builder: android.app.AlertDialog.Builder =
                android.app.AlertDialog.Builder(context)
            builder.setMessage("No weight data found. Would you like to generate some data for test purposes?")
            builder.setCancelable(true)

            // If the user clicks "Yes", generate some dummy data
            builder.setPositiveButton(
                "Yes"
            ) { dialog, id ->
                createDummyData()
                dialog.cancel()
            }

            builder.setNegativeButton(
                "No"
            ) { dialog, id -> dialog.cancel() }

            val alertBox: android.app.AlertDialog? = builder.create()
            alertBox?.show()
        }

        // Set up the recycler view
        val recyclerView = view.findViewById<RecyclerView>(R.id.recycler_daily_weights)
        recyclerView.layoutManager = GridLayoutManager(this.context, 1)
        recyclerView.adapter = RecyclerAdapter(recyclerData)
        sharedViewModel.myAdapter = recyclerView.adapter as RecyclerAdapter

        // Add dividers between rows in the recycler view
        recyclerView.addItemDecoration(RecyclerViewItemDecoration(requireContext(), R.drawable.recyclerview_divider))

        // Show the popup to add a weight
        binding.buttonAddWeight.setOnClickListener {
            val popupDailyWeightFragment = PopupDailyWeightFragment()
            popupDailyWeightFragment.show(parentFragmentManager, "popupDailyWeightFragment")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // Create dummy data for the recycler view
    private fun createDummyData(): MutableList<MyData> {
        val data = mutableListOf<MyData>()
        val formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy")

        // Create 10 rows of dummy data for the past 10 days
        for (i in 10 downTo 1) {
            val weight = Random.nextInt(100, 250) // Random weight between 100 and 250 lbs
            val date = LocalDate.now().minusDays(i.toLong()).format(formatter)
            data.add(MyData(i.toLong(), weight, date))

            val dbHelper = FeedReaderDbHelper(requireContext())
            val dbWrite = dbHelper.writableDatabase

            // Create a new map of values, where column names are the keys
            val values = ContentValues().apply {
                put(DailyWeights.COLUMN_NAME_USER_ID, MyApplication.instance.currentUserId)
                put(DailyWeights.COLUMN_NAME_WEIGHT, weight)
                put(DailyWeights.COLUMN_NAME_DATE, date)
            }

            // Insert the new row in the database, returning the primary key value of the new row
            val newRowId = dbWrite.insert(DailyWeights.TABLE_NAME, null, values)

            sharedViewModel.recyclerData.add(MyData(newRowId, weight, date))
            sharedViewModel.myAdapter.notifyItemInserted(sharedViewModel.recyclerData.size - 1)
        }

        return data

        // Add the new row to the recycler view and notify the adapter that it has changed
    }

    // Get the daily weights from the database
    private fun getDailyWeights(): MutableList<MyData> {
        val data = mutableListOf<MyData>()

        val dbHelper = FeedReaderDbHelper(requireContext())
        val db = dbHelper.readableDatabase

        // Filter results WHERE "title" = 'My Title'
        val selection = "${DailyWeights.COLUMN_NAME_USER_ID} = ?"
        val selectionArgs = arrayOf(MyApplication.instance.currentUserId.toString())

        val cursor = db.query(
            DailyWeights.TABLE_NAME,   // The table to query
            null,             // The array of columns to return (pass null to get all)
            selection,              // The columns for the WHERE clause
            selectionArgs,          // The values for the WHERE clause
            null,                   // don't group the rows
            null,                   // don't filter by row groups
            null               // The sort order
        )

        // Add the rows to the recycler view
        while (cursor.moveToNext()) {
            val id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID))
            val userId = cursor.getInt(cursor.getColumnIndexOrThrow(DailyWeights.COLUMN_NAME_USER_ID))
            val weight = cursor.getInt(cursor.getColumnIndexOrThrow(DailyWeights.COLUMN_NAME_WEIGHT))
            val date = cursor.getString(cursor.getColumnIndexOrThrow(DailyWeights.COLUMN_NAME_DATE))
//            println("ID: $id, User ID: $userId, Weight: $weight, Date: $date")

            data.add(MyData(id, weight, date))
        }

        return data
    }
}

