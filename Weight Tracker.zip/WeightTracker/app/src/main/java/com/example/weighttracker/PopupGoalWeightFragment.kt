package com.example.weighttracker

import android.app.AlertDialog
import android.app.Dialog
import android.content.ContentValues
import android.content.DialogInterface
import android.os.Bundle
import android.provider.BaseColumns
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import com.example.weighttracker.MainActivity.FeedReaderContract.Users
import com.example.weighttracker.MainActivity.FeedReaderContract.FeedReaderDbHelper

class PopupGoalWeightFragment: DialogFragment() {
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)
            // Get the layout inflater.
            val inflater = requireActivity().layoutInflater;
            val dialogView = inflater.inflate(R.layout.popup_goal_weight, null)
            val okButton = dialogView.findViewById<Button>(R.id.buttonSetWeight)
            val goalWeight = dialogView.findViewById<EditText>(R.id.goalWeight)
            val cancelButton = dialogView.findViewById<Button>(R.id.buttonCancel)

            // If the user has already set their phone number, pre-fill the field
            if (MyApplication.instance.currentUserGoalWeight > 0) {
                goalWeight.setText(MyApplication.instance.currentUserGoalWeight.toString())
            }

            // Enable or disable the OK button based on whether the EditText is empty
            goalWeight.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    okButton.isEnabled = s?.toString()?.isNotEmpty() == true
                }

                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    // Prevent user from entering decimal points
                    if (s.toString().contains(".")) {
                        goalWeight.setText(s.toString().replace(".", ""))
                        goalWeight.setSelection(goalWeight.text.length)
                    }

                    // Prevent user from entering 0
                    if (s.toString() == "0") {
                        goalWeight.setText("")
                    }
                }
            })

            // Handle OK button click
            okButton.setOnClickListener {
                setGoalWeight(goalWeight.text.toString().toInt())
                dialog?.dismiss()
            }

            // Close the dialog
            cancelButton.setOnClickListener {
                dialog?.dismiss()
            }

            // Inflate and set the layout for the dialog.
            builder.setView(dialogView)
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }

    // Set the goal weight for the user in the database
    private fun setGoalWeight(goalWeight: Int) {
        // Set the goal weight in the global variable
        MyApplication.instance.currentUserGoalWeight = goalWeight

        val dbHelper = FeedReaderDbHelper(requireContext())
        val dbWrite = dbHelper.writableDatabase

        // New value for one column
        val values = ContentValues().apply {
            put(Users.COLUMN_NAME_GOAL_WEIGHT, goalWeight)
        }

        // Which row to update, based on the ID
        val selection = "${BaseColumns._ID} LIKE ?"
        val selectionArgs = arrayOf(MyApplication.instance.currentUserId.toString())
        val count = dbWrite.update(
            Users.TABLE_NAME,
            values,
            selection,
            selectionArgs
        )
    }
}