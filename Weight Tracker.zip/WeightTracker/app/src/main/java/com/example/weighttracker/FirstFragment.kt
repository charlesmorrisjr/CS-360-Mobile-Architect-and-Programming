package com.example.weighttracker

import android.content.ContentValues
import android.content.DialogInterface
import android.os.Bundle
import android.provider.BaseColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.weighttracker.MainActivity.FeedReaderContract.Users
import com.example.weighttracker.MainActivity.FeedReaderContract.FeedReaderDbHelper
import com.example.weighttracker.databinding.FragmentFirstBinding


/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.buttonLogin.setOnClickListener {
            login()
        }

        binding.buttonCreateAccount.setOnClickListener {
            createAccount()
        }

        // Make the app bar disappear
        (activity as AppCompatActivity).supportActionBar?.hide()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun login() {
        val dbHelper = FeedReaderDbHelper(requireContext())
        val db = dbHelper.readableDatabase

        // Filter results WHERE
        val selection = "${Users.COLUMN_NAME_USERNAME} = ?"
        val selectionArgs = arrayOf(binding.editTextUsername.text.toString())

        val cursor = db.query(
            Users.TABLE_NAME,   // The table to query
            null,             // The array of columns to return (pass null to get all)
            selection,              // The columns for the WHERE clause
            selectionArgs,          // The values for the WHERE clause
            null,                   // don't group the rows
            null,                   // don't filter by row groups
            null               // The sort order
        )

        cursor.moveToNext() // Move to the first row of the result set

        if (cursor.count > 0 && cursor.getString(cursor.getColumnIndexOrThrow(Users.COLUMN_NAME_PASSWORD)) == binding.editTextPassword.text.toString()) {
            MyApplication.instance.currentUserId = cursor.getInt(cursor.getColumnIndexOrThrow(BaseColumns._ID))
            MyApplication.instance.currentUserGoalWeight = cursor.getInt(cursor.getColumnIndexOrThrow(Users.COLUMN_NAME_GOAL_WEIGHT))
            MyApplication.instance.currentUserPhoneNumber = cursor.getString(cursor.getColumnIndexOrThrow(Users.COLUMN_NAME_PHONE))

            findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
        } else {
            val builder: android.app.AlertDialog.Builder = android.app.AlertDialog.Builder(context)
            builder.setMessage("Incorrect username or password entered.")
            builder.setCancelable(true)

            builder.setPositiveButton(
                "OK",
                DialogInterface.OnClickListener { dialog, id -> dialog.cancel() })

            val alertBox: android.app.AlertDialog? = builder.create()
            alertBox?.show()
        }
    }

    private fun createAccount() {
        if (binding.editTextUsername.text.toString() != "" && binding.editTextPassword.text.toString() != "") {
            val dbHelper = FeedReaderDbHelper(requireContext())
            val db = dbHelper.readableDatabase

            // Filter results WHERE "title" = 'My Title'
            val selection = "${Users.COLUMN_NAME_USERNAME} = ?"
            val selectionArgs = arrayOf(binding.editTextUsername.text.toString())

            val cursor = db.query(
                Users.TABLE_NAME,   // The table to query
                null,             // The array of columns to return (pass null to get all)
                selection,              // The columns for the WHERE clause
                selectionArgs,          // The values for the WHERE clause
                null,                   // don't group the rows
                null,                   // don't filter by row groups
                null               // The sort order
            )

            if (cursor.count == 0) {
                // Gets the data repository in write mode
                val dbWrite = dbHelper.writableDatabase

                // Create a new map of values, where column names are the keys
                val values = ContentValues().apply {
                    put(Users.COLUMN_NAME_USERNAME, binding.editTextUsername.text.toString())
                    put(Users.COLUMN_NAME_PASSWORD, binding.editTextPassword.text.toString())
                    put(Users.COLUMN_NAME_PHONE, "")
                }

                // Insert the new row, returning the primary key value of the new row
                val newRowId = dbWrite?.insert(Users.TABLE_NAME, null, values)

                val popupGoalWeightFragment = PopupGoalWeightFragment()
                popupGoalWeightFragment.show(parentFragmentManager, "popupGoalWeightFragment")

                // Call login function to set the current user ID
                login()
            } else {
                val builder: android.app.AlertDialog.Builder =
                    android.app.AlertDialog.Builder(context)
                builder.setMessage("Account already exists.")
                builder.setCancelable(true)

                builder.setPositiveButton(
                    "OK",
                    DialogInterface.OnClickListener { dialog, id -> dialog.cancel() })

                val alertBox: android.app.AlertDialog? = builder.create()
                alertBox?.show()
            }
        }
    }
}