package com.example.weighttracker

import android.app.Application
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.provider.BaseColumns
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.view.Menu
import android.view.MenuItem
import androidx.lifecycle.ViewModel
import com.example.weighttracker.MainActivity.FeedReaderContract.Users
import com.example.weighttracker.MainActivity.FeedReaderContract.DailyWeights
import com.example.weighttracker.MainActivity.FeedReaderContract.FeedReaderDbHelper
import com.example.weighttracker.databinding.ActivityMainBinding
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MyApplication : Application() {
    // Create global variable currentUserId to use throughout the app
    var currentUserId: Int = 0
    var currentUserGoalWeight: Int = 0
    var currentUserPhoneNumber: String = ""

    companion object {
        lateinit var instance: MyApplication
            private set

    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}
// Create a shared view model to share data between SecondFragment and PopupDailyWeightFragment.
// This allows us to update and access the recycler view data from both fragments.
class SharedViewModel : ViewModel() {
    lateinit var myAdapter: RecyclerAdapter
    lateinit var recyclerData: MutableList<MainActivity.MyData>
}

class MainActivity : AppCompatActivity() {
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    // Create a data class to hold the weight and date for the RecyclerView
    data class MyData(val id: Long, var weight: Int, val date: String)

    object FeedReaderContract {
        // Table contents are grouped together in an anonymous object.
        object Users : BaseColumns {
            const val TABLE_NAME = "users"
            const val COLUMN_NAME_USERNAME = "username"
            const val COLUMN_NAME_PASSWORD = "password"
            const val COLUMN_NAME_GOAL_WEIGHT = "goal_weight"
            const val COLUMN_NAME_PHONE = "phone"
        }

        object DailyWeights : BaseColumns {
            const val TABLE_NAME = "daily_weights"
            const val COLUMN_NAME_USER_ID = "user_id"
            const val COLUMN_NAME_WEIGHT = "weight"
            const val COLUMN_NAME_DATE = "date"
        }

        private const val SQL_CREATE_FEED_ENTRIES =
            "CREATE TABLE ${Users.TABLE_NAME} (" +
                "${BaseColumns._ID} INTEGER PRIMARY KEY," +
                "${Users.COLUMN_NAME_USERNAME} TEXT," +
                "${Users.COLUMN_NAME_PASSWORD} TEXT," +
                "${Users.COLUMN_NAME_GOAL_WEIGHT} INTEGER," +
                "${Users.COLUMN_NAME_PHONE} TEXT)"

        private const val SQL_CREATE_DAILY_WEIGHT_ENTRIES =
            "CREATE TABLE ${DailyWeights.TABLE_NAME} (" +
                "${BaseColumns._ID} INTEGER PRIMARY KEY," +
                "${DailyWeights.COLUMN_NAME_USER_ID} INTEGER," +
                "${DailyWeights.COLUMN_NAME_WEIGHT} TEXT," +
                "${DailyWeights.COLUMN_NAME_DATE} TEXT)"

        private const val SQL_DELETE_FEED_ENTRIES = "DROP TABLE IF EXISTS ${Users.TABLE_NAME}"
        private const val SQL_DELETE_DAILY_WEIGHT_ENTRIES = "DROP TABLE IF EXISTS ${DailyWeights.TABLE_NAME}"

        class FeedReaderDbHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
            override fun onCreate(db: SQLiteDatabase) {
                db.execSQL(SQL_CREATE_FEED_ENTRIES)
                db.execSQL(SQL_CREATE_DAILY_WEIGHT_ENTRIES)
            }
            override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
                // This database is only a cache for online data, so its upgrade policy is
                // to simply to discard the data and start over
                db.execSQL(SQL_DELETE_FEED_ENTRIES)
                db.execSQL(SQL_DELETE_DAILY_WEIGHT_ENTRIES)
                onCreate(db)
            }
            override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
                onUpgrade(db, oldVersion, newVersion)
            }
            companion object {
                // If you change the database schema, you must increment the database version.
                const val DATABASE_VERSION = 2
                const val DATABASE_NAME = "WeightTracker.db"
            }
        }


    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        // Hide the app bar initially on the login fragment
        supportActionBar?.hide()

        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)

        debugPrintDatabaseContents()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            // Open the popup to set the goal weight
            R.id.action_setGoalWeight -> {
                openGoalWeightPopup()
                true
            }

            // Open the popup to set SMS notification permission
            R.id.action_smsNotifications -> {
                openSmsPermissionPopup()
                true
            }

            // Navigate back to the login fragment
            R.id.action_logout -> {
                onSupportNavigateUp()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun openGoalWeightPopup() {
        val popupGoalWeightFragment = PopupGoalWeightFragment()
        popupGoalWeightFragment.show(supportFragmentManager, "PopupGoalWeight")
    }

    private fun openSmsPermissionPopup() {
        val popupSmsPermissionFragment = SmsPermissionFragment()
        popupSmsPermissionFragment.show(supportFragmentManager, "SmsPermissionFragment")
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }

    private fun debugPrintDatabaseContents () {
        val dbHelper = FeedReaderDbHelper(this)
        val db = dbHelper.readableDatabase

        val cursor = db.query(
            Users.TABLE_NAME,   // The table to query
            null,             // The array of columns to return (pass null to get all)
            null,              // The columns for the WHERE clause
            null,          // The values for the WHERE clause
            null,                   // don't group the rows
            null,                   // don't filter by row groups
            null               // The sort order
        )

        // print contents of cursor to the console
        while (cursor.moveToNext()) {
            val id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID))
            val username = cursor.getString(cursor.getColumnIndexOrThrow(Users.COLUMN_NAME_USERNAME))
            val password = cursor.getString(cursor.getColumnIndexOrThrow(Users.COLUMN_NAME_PASSWORD))
            val goalWeight = cursor.getString(cursor.getColumnIndexOrThrow(Users.COLUMN_NAME_GOAL_WEIGHT))
            val phone = cursor.getString(cursor.getColumnIndexOrThrow(Users.COLUMN_NAME_PHONE))
            println("ID: $id, Username: $username, Password: $password, Goal Weight: $goalWeight, Phone: $phone")
        }

        val cursor2 = db.query(
            DailyWeights.TABLE_NAME,   // The table to query
            null,             // The array of columns to return (pass null to get all)
            null,              // The columns for the WHERE clause
            null,          // The values for the WHERE clause
            null,                   // don't group the rows
            null,                   // don't filter by row groups
            null               // The sort order
        )

        // print contents of cursor to the console
        while (cursor2.moveToNext()) {
            val id = cursor2.getLong(cursor2.getColumnIndexOrThrow(BaseColumns._ID))
            val userId = cursor2.getString(cursor2.getColumnIndexOrThrow(DailyWeights.COLUMN_NAME_USER_ID))
            val weight = cursor2.getString(cursor2.getColumnIndexOrThrow(DailyWeights.COLUMN_NAME_WEIGHT))
            val date = cursor2.getString(cursor2.getColumnIndexOrThrow(DailyWeights.COLUMN_NAME_DATE))
            println("ID: $id, User ID: $userId, Weight: $weight, Date: $date")
        }

        println("Current date: ${LocalDate.now().format(DateTimeFormatter.ofPattern("MM-dd-yyyy"))}")
    }
}
