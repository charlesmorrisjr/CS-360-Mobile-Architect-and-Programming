package com.example.weighttracker

import android.app.AlertDialog
import android.app.Dialog
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import androidx.core.app.ActivityCompat
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.activityViewModels
import com.example.weighttracker.MainActivity.FeedReaderContract.DailyWeights
import com.example.weighttracker.MainActivity.FeedReaderContract.FeedReaderDbHelper
import com.example.weighttracker.MainActivity.MyData
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class PopupDailyWeightFragment: DialogFragment() {
    private val sharedViewModel: SharedViewModel by activityViewModels()

    private var todaysWeight = 0

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)
            // Get the layout inflater.
            val inflater = requireActivity().layoutInflater;
            val dialogView = inflater.inflate(R.layout.popup_daily_weight, null)
            val okButton = dialogView.findViewById<Button>(R.id.buttonSetWeight)
            val dailyWeight = dialogView.findViewById<EditText>(R.id.dailyWeight)
            val cancelButton = dialogView.findViewById<Button>(R.id.buttonCancel)

            todaysWeight = getTodaysWeight()

            // If the user has already set their weight for today, pre-fill the field
            if (todaysWeight > 0) {
                dailyWeight.setText(todaysWeight.toString())
                okButton.isEnabled = true
            }

            // Enable or disable the OK button based on whether the EditText is empty
            dailyWeight.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    okButton.isEnabled = s?.toString()?.isNotEmpty() == true
                }

                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    // Prevent user from entering decimal points
                    if (s.toString().contains(".")) {
                        dailyWeight.setText(s.toString().replace(".", ""))
                        dailyWeight.setSelection(dailyWeight.text.length)
                    }

                    // Prevent user from entering 0
                    if (s.toString() == "0") {
                        dailyWeight.setText("")
                    }
                }
            })

            // Handle OK button click
            okButton.setOnClickListener {
                setDailyWeight(dailyWeight.text.toString().toInt())
                dialog?.dismiss()
            }

            // Close the dialog
            cancelButton.setOnClickListener {
                dialog?.dismiss()
            }

            // Inflate and set the layout for the dialog.
            builder.setView(dialogView)
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }

    // Set the daily weight in the database
    private fun setDailyWeight (dailyWeight: Int) {
        // Gets the data repository in write mode
        val dbHelper = FeedReaderDbHelper(requireContext())
        val dbWrite = dbHelper.writableDatabase

        // Get current date
        val date = LocalDate.now().format(DateTimeFormatter.ofPattern("MM-dd-yyyy"))

        // No weight has been set for today, so add one
        if (todaysWeight == 0) {
            // Create a new map of values, where column names are the keys
            val values = ContentValues().apply {
                put(DailyWeights.COLUMN_NAME_USER_ID, MyApplication.instance.currentUserId)
                put(DailyWeights.COLUMN_NAME_WEIGHT, dailyWeight)
                put(DailyWeights.COLUMN_NAME_DATE, date)
            }

            // Insert the new row in the database, returning the primary key value of the new row
            val newRowId = dbWrite.insert(DailyWeights.TABLE_NAME, null, values)

            // Add the new row to the recycler view and notify the adapter that it has changed
            sharedViewModel.recyclerData.add(MyData(newRowId, dailyWeight, date))
            sharedViewModel.myAdapter.notifyItemInserted(sharedViewModel.recyclerData.size - 1)

        // Weight has already been set for today, so update it
        } else {
            // New value for one column
            val values = ContentValues().apply {
                put(DailyWeights.COLUMN_NAME_WEIGHT, dailyWeight)
            }

            // Which row to update
            val selection = "${DailyWeights.COLUMN_NAME_USER_ID} LIKE ? AND ${DailyWeights.COLUMN_NAME_DATE} LIKE ?"
            val selectionArgs = arrayOf(MyApplication.instance.currentUserId.toString(), date)
            val count = dbWrite.update(
                DailyWeights.TABLE_NAME,
                values,
                selection,
                selectionArgs
            )

            // Update the recycler view and notify the adapter that it has changed
            sharedViewModel.recyclerData[sharedViewModel.recyclerData.size - 1].weight = dailyWeight
            sharedViewModel.myAdapter.notifyItemChanged(sharedViewModel.recyclerData.size - 1)
        }

        // If the user has reached their goal weight, show a popup and send an SMS notification
        if (dailyWeight == MyApplication.instance.currentUserGoalWeight) {
            popupReachedGoalWeight()
            sendSMSNotification()
        }
    }

    // Get the weight for today from the database
    private fun getTodaysWeight(): Int {
        val currentDate = LocalDate.now().format(DateTimeFormatter.ofPattern("MM-dd-yyyy"))

        val dbHelper = FeedReaderDbHelper(requireContext())
        val db = dbHelper.readableDatabase

        // Select the row with the current date and user ID
        val selection = "${DailyWeights.COLUMN_NAME_USER_ID} LIKE ? AND ${DailyWeights.COLUMN_NAME_DATE} LIKE ?"
        val selectionArgs = arrayOf(MyApplication.instance.currentUserId.toString(), currentDate)

        val cursor = db.query(
            DailyWeights.TABLE_NAME,   // The table to query
            null,             // The array of columns to return (pass null to get all)
            selection,              // The columns for the WHERE clause
            selectionArgs,          // The values for the WHERE clause
            null,                   // don't group the rows
            null,                   // don't filter by row groups
            null               // The sort order
        )

        // If no rows are returned, return 0
        if (cursor.count == 0) {
            cursor.close()
            return 0
        // If rows are returned, return the weight
        } else {
            cursor.moveToNext()

            val weight = cursor.getString(cursor.getColumnIndexOrThrow(DailyWeights.COLUMN_NAME_WEIGHT))

            cursor.close()

            return weight.toInt()
        }
    }

    // Show a popup to inform the user that they have reached their goal weight
    private fun popupReachedGoalWeight() {
        val builder: AlertDialog.Builder =
            AlertDialog.Builder(context)
        builder.setMessage("Congratulations! You reached your goal weight!")
        builder.setCancelable(true)

        builder.setPositiveButton(
            "OK"
        ) { dialog, id -> dialog.cancel() }

        val alertBox: AlertDialog? = builder.create()
        alertBox?.show()
    }

    // Send an SMS notification to the user that they have reached their goal weight
    private fun sendSMSNotification () {
        fun sendSms(phoneNumber: String, message: String) {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
        }

        // If app has permission to send SMS, send notification
        if (ActivityCompat.checkSelfPermission(requireContext(), android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendSms("1" + MyApplication.instance.currentUserPhoneNumber, "Congratulations! You reached your goal weight!")
            println("1" + MyApplication.instance.currentUserPhoneNumber);
        }

    }
}
