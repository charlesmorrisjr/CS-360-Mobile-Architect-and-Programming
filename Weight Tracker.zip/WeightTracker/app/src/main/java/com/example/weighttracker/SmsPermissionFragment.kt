package com.example.weighttracker

import android.app.AlertDialog
import android.app.Dialog
import android.content.ContentValues
import android.os.Bundle
import android.provider.BaseColumns
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.DialogFragment
import com.example.weighttracker.MainActivity.FeedReaderContract.Users
import com.example.weighttracker.MainActivity.FeedReaderContract.FeedReaderDbHelper

class SmsPermissionFragment: DialogFragment() {
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)

            // Get the layout inflater.
            val inflater = requireActivity().layoutInflater;
            val dialogView = inflater.inflate(R.layout.popup_sms_permission, null)
            val okButton = dialogView.findViewById<Button>(R.id.buttonOptIn)
            val phoneNumber = dialogView.findViewById<EditText>(R.id.phoneNumber)
            val cancelButton = dialogView.findViewById<Button>(R.id.buttonCancel)

            // If the user has already set their phone number, pre-fill the field
            if (MyApplication.instance.currentUserPhoneNumber != "") {
                phoneNumber.setText(MyApplication.instance.currentUserPhoneNumber)
            }

            // Enable the OK button if the phone number is 10 digits long
            phoneNumber.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    okButton.isEnabled = s?.toString()?.length == 10
                }

                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            })

            // Handle OK button click
            okButton.setOnClickListener {
                // Set the current user's phone number
                setUsersPhoneNumber(phoneNumber.text.toString())
                dialog?.dismiss()
            }

            // Close the dialog
            cancelButton.setOnClickListener {
                dialog?.dismiss()
            }

            // Inflate and set the layout for the dialog.
            builder.setView(dialogView)
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }

    // Set the current user's phone number
    private fun setUsersPhoneNumber(phoneNumber: String) {
        MyApplication.instance.currentUserPhoneNumber = phoneNumber

        val dbHelper = FeedReaderDbHelper(requireContext())
        val dbWrite = dbHelper.writableDatabase

        // Set the phone number in the database
        val values = ContentValues().apply {
            put(Users.COLUMN_NAME_PHONE, phoneNumber)
        }

        // Update the row based on the ID
        val selection = "${BaseColumns._ID} LIKE ?"
        val selectionArgs = arrayOf(MyApplication.instance.currentUserId.toString())
        val count = dbWrite.update(
            Users.TABLE_NAME,
            values,
            selection,
            selectionArgs
        )
    }
}