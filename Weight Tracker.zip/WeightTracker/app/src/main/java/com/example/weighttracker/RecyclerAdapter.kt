package com.example.weighttracker

import android.provider.BaseColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.weighttracker.MainActivity.FeedReaderContract
import com.example.weighttracker.MainActivity.FeedReaderContract.DailyWeights

class RecyclerAdapter(private val data: MutableList<MainActivity.MyData>) : RecyclerView.Adapter<RecyclerAdapter.MyViewHolder>() {

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val weightTextView: TextView = itemView.findViewById(R.id.weightTextView)
        val dateTextView: TextView = itemView.findViewById(R.id.dateTextView)
        val deleteButton: ImageButton = itemView.findViewById(R.id.deleteButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        // Create a new view, which defines the UI of the list item
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.text_row_item, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = data[position]
        holder.weightTextView.text = currentItem.weight.toString()
        holder.dateTextView.text = currentItem.date

        // Set the click listener for the delete button
        holder.deleteButton.setOnClickListener {
            // Remove the item from the data list and notify the adapter
            data.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, data.size)

            // Remove the item from the database
            val dbHelper = FeedReaderContract.FeedReaderDbHelper(holder.itemView.context)
            val db = dbHelper.writableDatabase

            // Select the row to delete based on the ID and date
            val selection = "${DailyWeights.COLUMN_NAME_USER_ID} LIKE ? AND ${DailyWeights.COLUMN_NAME_DATE} LIKE ?"
            val selectionArgs = arrayOf(MyApplication.instance.currentUserId.toString(), currentItem.date)

            val deletedRows = db.delete(DailyWeights.TABLE_NAME, selection, selectionArgs)
        }
    }

    override fun getItemCount(): Int {
        return data.size
    }
}
